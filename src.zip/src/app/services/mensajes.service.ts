import { Injectable } from '@angular/core';
import Swal from 'sweetalert2';
import { UsersService } from './users.service';
import { Usuario } from '../clases/usuario';

@Injectable({
  providedIn: 'root'
})
export class MensajesService {

  constructor(private users : UsersService) { }

  ingreso() {
    Swal.fire({
      title: 'Ingresado correctamente',
      confirmButtonText: 'Genial',
      allowEnterKey: true
    });
  }

  usuarioIncorrecto() {
    Swal.fire({
      title: 'Error!',
      text: 'El usuario o contraseña es erroneo',
      icon: 'error',
      confirmButtonText: 'Entendido',
      allowEnterKey: true
    })
  }

  preguntarBorrado(usuario : Usuario,indice : number){
    Swal.fire({
      title: 'Estas seguro de borrar al chofer '+usuario.chofer?.legajo+'?',
      text: "No vas a poder ir para atras!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Si, borrar!',
      cancelButtonText: 'Cancelar',
      allowEnterKey: true,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        Swal.fire('Chofer '+usuario.chofer?.legajo+' borrado!', '', 'success')
        this.users.borrarUsuario(indice);
      } else if (result.isDismissed) {
        Swal.fire('No se borro el chofer '+usuario.chofer?.legajo, '', 'info')
      }
    })
  }


}
